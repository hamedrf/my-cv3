export const Tag = (props: { text: string }) => {
  return <span className=" rounded rounded-3 tag-Portfolio">{props.text}</span>;
};

export default Tag;
